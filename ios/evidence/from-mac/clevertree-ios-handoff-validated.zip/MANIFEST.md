# Clevertree iOS handoff package

| Folder | Contents | Refresh alone? |
|---|---|---|
| **A-sources/** | `ClevertreeRoom` SPM + `ClevertreeApp` host | Yes — re-copy from `ios/` |
| **B-docs/** | `HANDOFF.md`, README, `ios-room.md` | Yes — edit docs, re-zip |
| **C-scripts/** | Asset sync + packaging scripts | Yes — edit scripts, re-zip |

Start on a Mac with **B-docs/HANDOFF.md**.

Rebuild this zip from the repo:

```bash
bash ios/scripts/package-handoff.sh
```
