# Clevertree Chat iOS simulator validation

November 27, 2026. Xcode 26.3 (17C529), XcodeGen 2.49.0, iOS Simulator 26.3.1 (23D8133). The Debug app opened the live public #web room using the bundled WebView assets.

| Target | Result |
| --- | --- |
| ClevertreeRoom Swift package on macOS | 5 passed |
| iPhone 17 Pro | 6 passed. The iPad orientation check was skipped by design. |
| iPhone SE (3rd generation) | 6 passed. The iPad orientation check was skipped by design. |
| iPad (10th generation) | 7 passed, including portrait and landscape. |

The simulator suite verified the host bundle ID, room launch, default channel, channel list, attachment menu with a Photo Library option, and the composer. Draft entry, keyboard dismissal, and placement of Send above the on-screen keyboard were exercised. Screenshots show the room inside the safe area with the attachment and audio controls visible. The draft remained unsent.

On iPhone SE, the landscape-style split layout shown while editing leaves a narrow transcript column. The composer and Send stayed usable, but the title truncated and transcript words wrapped across several lines. The iPad layout had space for all three panes.

Web Inspector connected to the Debug WKWebView and confirmed the bundled room URL, #web channel, and composer name. Simulator WebKit supplied audio and video tracks in separate probes. Each track was stopped immediately. Native permission prompt appearance and physical-device recording remain to be verified on a real device. The attachment test opened the picker options and stopped before selecting a photo. The built plist retains all four media usage descriptions and ATS keeps arbitrary loads disabled. Device signing and App Store disclosure belong to a device release.

## Changes needed to run the handoff

- The app now uses Swift language mode 5 and the shipped Info.plist. XcodeGen no longer regenerates that plist. The hosted test points at the ClevertreeChat executable.
- The package uses its resource bundle inside the method and initializer bodies. The scheme handler implements the WebKit start and stop delegate signatures.
- The host and UI test stubs now exercise the behaviors above. The channel control is found by its accessibility label because WebKit exposes it to XCTest as an Other element.

Run XcodeGen from A-sources/ClevertreeApp before building. The archive includes the original bundled room assets. The consolidated logs, screenshots, and Xcode test summary are in Simulator Evidence beside this handoff's source and documentation directories on the test Mac.
